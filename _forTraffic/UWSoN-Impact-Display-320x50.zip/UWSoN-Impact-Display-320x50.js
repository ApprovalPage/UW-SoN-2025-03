(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"UWSoN_Impact_Display_320x50_atlas_P_1", frames: [[0,0,622,116],[0,118,504,116],[506,118,167,75]]},
		{name:"UWSoN_Impact_Display_320x50_atlas_NP_1", frames: [[0,0,640,100]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.HEAD1a2x = function() {
	this.initialize(ss["UWSoN_Impact_Display_320x50_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.HEAD1b2x = function() {
	this.initialize(ss["UWSoN_Impact_Display_320x50_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.LOGO300x2502x = function() {
	this.initialize(ss["UWSoN_Impact_Display_320x50_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.UWNursingimpact320x50 = function() {
	this.initialize(ss["UWSoN_Impact_Display_320x50_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.LOGO300x2502x();
	this.instance.setTransform(-41.75,-18.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.7,-18.7,83.5,37.5);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.LOGO300x2502x();
	this.instance.setTransform(-41.75,-18.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.7,-18.7,83.5,37.5);


(lib.SUBHEAD = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AggAiIAAhCIAPAAIAAAIQADgDAFgCQAIgEAGAAQAJAAAFAEQAHADADAGQAEAGAAAKIAAAmIgQAAIAAgjQAAgIgEgGQgEgEgHAAQgFAAgEACQgEACgDAFQgCAEAAAGIAAAig");
	this.shape.setTransform(-22.825,10.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgHAwIAAhBIAOAAIAABBgAgGgfQgDgDAAgEQAAgDADgDQACgDAEAAQAEAAADADQADACAAAEQAAAEgDACQgCADgFABQgDAAgDgDg");
	this.shape_1.setTransform(-28.9,8.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSAiIAAhCIAPAAIAAAJQADgEADgCQAGgEAKAAIAAAPIgDAAQgKAAgFAFQgEAFAAAJIAAAhg");
	this.shape_2.setTransform(-36.475,10.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AADAiQgKAAgJgEQgIgFgEgHQgFgJAAgJQAAgIAEgJQAFgHAIgFQAHgEAKAAQAJAAAIAEQAIAEAEAIQAEAIAAAJIAAAFIgzAAIACAGQACAFAGACQAEADAGAAQAGAAAFgCQAFgCADgDIAIAJQgFAFgGADQgHADgJAAgAgIgSIgHAHIgCAHIAlAAQgBgEgCgDQgCgEgEgDQgFgDgFAAQgEAAgFADg");
	this.shape_3.setTransform(-43.325,10.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgQAeQgIgFgFgHQgEgIAAgKQAAgJAEgIQAFgHAHgFQAJgEAIAAQAKAAAIAEQAHAEAFAIQAEAIAAAJIAAADIAAACIg0AAIADAGQADAFAFACQAEADAGAAQAGAAAEgCQAFgCADgDIAJAJQgEAFgIADQgGADgJAAQgKAAgJgEgAgJgSQgEADgCAEQgCADgBAEIAmAAIgDgHIgHgHQgFgDgFAAQgEAAgFADg");
	this.shape_4.setTransform(-51.075,10.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTAiIABgBIAAhBIAOAAIAAAKQADgFAFgCQAFgEALAAIAAAPIgFAAQgIAAgFAFQgFAFAAAJIAAAhg");
	this.shape_5.setTransform(-57.15,10.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRAgQgHgDgCgEQgDgFAAgGQAAgFACgFQADgEAGgCQAGgDAKAAIARAAIAAgBQAAgGgEgEQgEgEgIAAQgGAAgFACQgGABgDAEIgGgMQAEgEAJgCIAOgCQAOAAAIAHQAIAGAAAPIAAAmIgOAAIAAgIQgDAEgEACQgGADgHAAQgHAAgGgCgAgLAHQgDAEAAADQAAAEADADQAEACAGAAQAFAAAEgDQAEgCADgFIAAgIIgPAAQgIAAgDACg");
	this.shape_6.setTransform(-64.125,10.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAeQgIgFgEgHQgGgHAAgLQAAgIAGgJQAEgHAIgFQAIgEAKAAQAJAAAIAEQAHAEAEAHIgMAHQgDgFgEgCQgEgCgGAAQgFAAgEADQgDABgEAGQgCAEAAAGQAAAGACAFQADAFAEACQAEADAFAAQAGAAAEgCQAEgCADgFIAMAHQgFAIgGADQgGAEgLAAQgKAAgIgEg");
	this.shape_7.setTransform(-71.25,10.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRAgQgHgDgCgEQgDgFAAgGQAAgFACgFQADgEAGgCQAGgDAKAAIARAAIAAgBQAAgGgEgEQgEgEgIAAQgGAAgFACQgGACgDADIgGgMQAEgEAJgCIAOgCQAOAAAIAHQAIAGAAAPIAAAmIgOAAIAAgIQgDAEgEACQgGADgHAAQgHAAgGgCgAgLAHQgDAEAAADQAAAEAEADQADACAGAAQAFAAAEgDQAEgCADgFIAAgIIgPAAQgIAAgDACg");
	this.shape_8.setTransform(-82.425,10.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgGgIQgEgIAAgKQAAgJAEgIQAFgHAIgFQAHgEAJAAQAKAAAIAEQAHAEAFAIQAEAIAAAJIAAADIAAACIgzAAIACAGQADAFAFACQAEADAGAAQAGAAAEgCQAFgCADgDIAJAJQgEAFgIADQgGADgJAAQgKAAgJgEgAgJgSQgEADgCAEIgCAHIAkAAIgCgHIgHgHQgFgDgFAAQgEAAgFADg");
	this.shape_9.setTransform(-93.325,10.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSAiIAAhCIAPAAIAAAJQADgEADgCQAGgEAKAAIAAAPIgDAAQgKAAgFAFQgEAFAAAJIAAAhg");
	this.shape_10.setTransform(-99.375,10.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRAeQgJgFgEgHQgEgIAAgKQAAgJAEgIQAEgHAJgFQAIgEAJAAQALAAAHAEQAJAFADAHQAGAJAAAIQAAALgGAHQgDAHgJAFQgHAEgLAAQgJAAgIgEgAgJgRQgEACgDAFQgDAFAAAFQAAAFADAGQADAGAEABQAEADAFAAQAHAAADgDQAFgCACgFQACgGAAgFQAAgFgCgFQgCgFgFgCQgDgDgHAAQgFAAgEADg");
	this.shape_11.setTransform(-106.35,10.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHAuIAAhbIAPAAIAABbg");
	this.shape_12.setTransform(-112.225,8.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgiAuIAAhaIAPAAIAAAIQADgDAEgCQAFgEAJAAQAKAAAHAFQAIADAEAIQAEAIAAAKQAAAJgEAIQgEAJgIADQgHAEgKABQgIAAgGgFIgHgFIAAAhgAgJgdQgFADgCAEQgDAEAAAHQAAAGADAFQACAEAFACQAEADAFAAQAHAAADgDQAEgBADgFQADgFAAgGQAAgGgDgFQgDgFgEgCQgDgCgHAAQgFAAgEACg");
	this.shape_13.setTransform(-118.025,11.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AARAhIgRgXIgQAXIgSAAIAbghIgZggIARAAIAPAVIARgVIARAAIgaAgIAbAhg");
	this.shape_14.setTransform(-126.175,10.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AggAsIAAhXIA/AAIAAAOIgvAAIAAAXIApAAIAAAMIgpAAIAAAYIAxAAIAAAOg");
	this.shape_15.setTransform(-133.525,9.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgGAHQgDgDAAgEQAAgEADgDQACgCAEAAQAFAAACACQADADAAAEQAAAFgDACQgDADgEAAQgDAAgDgDg");
	this.shape_16.setTransform(13.025,28.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgRAsQgJgCgGgFIAHgMQAFAEAGACQAGACAIAAQAKAAAFgFQAFgGAAgJIAAgEQgDAEgEACQgHADgHAAQgLAAgGgEQgIgEgEgHQgFgGAAgKQAAgJAFgIQAEgGAIgFQAIgEAJAAQAGAAAIADQAFADADADIAAgIIAPAAIAAA3QAAATgJAIQgJAIgSAAQgJAAgIgCgAgJgdQgFACgDAEQgCADAAAHQAAAHACADQAEAEAEACQAFACAEAAQAGAAAFgCQAEgDADgDQADgEAAgGQAAgGgDgEQgCgEgFgCQgFgDgGAAQgEAAgFADg");
	this.shape_17.setTransform(6.875,27.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggAiIAAhCIAPAAIAAAIQADgDAFgCQAIgEAGAAQAJAAAFAEQAHADADAGQAEAGAAAKIAAAmIgQAAIAAgjQAAgIgEgGQgEgEgIAAQgEAAgEACQgEACgDAFQgCAFAAAFIAAAig");
	this.shape_18.setTransform(-1.475,26.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHAwIAAhBIAOAAIAABBgAgGgfQgDgDAAgEQAAgEADgCQACgDAEAAQAEAAADADQADACAAAEQAAAEgDACQgCADgFABQgDAAgDgDg");
	this.shape_19.setTransform(-7.55,24.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAAAiQgJAAgHgCQgHgCgFgDIAGgMIALAFIALACQAHAAAEgCQADgDAAgDQAAgDgCgBIgGgCIgQgDIgIgDQgEgCgCgDQgCgDAAgGQAAgHADgEQADgFAHgDQAGgCAJAAIAOABQAGACAFADIgGALIgKgDQgEgCgFAAQgGAAgEADQgDABAAAEQAAADACABIAGADIAHABIAJACIAIADQADABADADQACAEAAAFQAAAGgEAFQgEAFgGADQgHACgIAAg");
	this.shape_20.setTransform(-12.625,26.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgSAiIgBgBIAAhBIAQAAIAAAKQACgFAEgCQAHgEAJAAIAAAPIgDAAQgJAAgGAFQgDAFAAAJIAAAhg");
	this.shape_21.setTransform(-18.1,26.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgSAfQgGgDgEgHQgEgHAAgKIAAglIAQAAIAAAjQAAAJAEAFQAEAEAIAAQAFAAADgCQAEgDADgEQACgEAAgHIAAghIAQAAIAABCIgPAAIAAgJQgDAEgFACQgHAEgGAAQgJAAgGgDg");
	this.shape_22.setTransform(-25.325,26.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AggAiIAAhCIAPAAIAAAJQADgEAFgCQAIgEAGAAIAAAAQAJAAAFAEQAHADADAGQAEAGAAAKIAAAmIgQAAIAAgjQAAgIgEgGQgEgEgIAAQgFAAgDACQgEACgDAFQgCAEAAAGIAAAig");
	this.shape_23.setTransform(-33.825,26.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgQAeQgIgFgFgHQgEgIAAgKQAAgJAEgIQAFgHAHgFQAJgEAIAAQAKAAAIAEQAHAEAFAIQAEAIAAAJIAAADIAAACIgzAAIACAGQADAFAFACQAEADAGAAQAGAAAEgCQAGgDACgCIAJAJQgEAFgIADQgGADgJAAQgKAAgJgEgAgJgSQgFAEgBADIgCAHIAlAAIgDgHIgHgHQgEgDgGAAQgEAAgFADg");
	this.shape_24.setTransform(-45.475,26.075);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgSAiIAAhCIAPAAIAAAJQADgEADgCQAGgEAKAAIAAAPIgDAAQgKAAgFAFQgEAFAAAJIAAAhg");
	this.shape_25.setTransform(-51.525,26.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgRAgQgGgDgDgEQgDgFAAgGQAAgFADgFQACgEAGgCQAHgDAKAAIAQAAIAAgBQAAgHgEgDQgEgEgIAAQgGAAgFACQgFABgEAEIgGgMQAGgEAHgCIAOgCQAOAAAJAHQAHAHAAAOIAAAmIgOAAIAAgHQgDADgEACQgFADgIAAQgHAAgGgCgAgLAHQgDADAAAEQAAAEAEADQADACAGAAQAFAAAEgDQAFgCACgFIAAgIIgPAAQgIAAgDACg");
	this.shape_26.setTransform(-58.525,26.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgOAeQgIgFgFgHQgEgIAAgKQAAgJAEgIQAFgHAIgFQAJgEAJAAQAJAAAIAEQAHAEAEAHIgMAHQgDgFgEgCQgEgCgFAAQgGAAgEADQgEACgDAFQgDAFAAAFQAAAGADAFQADAFAEACQAEADAGAAQAFAAAEgCQAEgCADgFIAMAHQgEAHgHAEQgHAEgKAAQgJAAgJgEg");
	this.shape_27.setTransform(-65.625,26.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAoAiIAAgjQAAgIgEgFQgDgFgIAAQgFAAgEACQgEACgCAFQgCAEAAAGIAAAiIgPAAIAAgjQAAgIgEgFQgDgFgIAAQgFAAgEACQgEACgCAFQgCAEAAAGIAAAiIgQAAIAAhCIAPAAIAAAJQADgEAEgCQAHgEAIAAQAKAAAGAFQADADACAEQADgEAFgDQAHgFAKAAQAJAAAFAEQAHADADAGQAEAHAAAKIAAAlg");
	this.shape_28.setTransform(-79.325,26.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgSAiIAAhCIAPAAIAAAJQADgEADgCQAHgEAJAAIAAAPIgDAAQgJAAgFAFQgFAFAAAJIAAAhg");
	this.shape_29.setTransform(-88.175,26.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgQAeQgHgEgGgIQgEgIAAgKQAAgJAEgIQAFgHAIgFQAHgEAJAAQAKAAAIAEQAHAEAFAIQAEAIAAAJIAAADIAAACIgzAAIACAGQADAFAFACQAEADAGAAQAGAAAEgCQAGgDACgCIAJAJQgEAFgIADQgGADgJAAQgKAAgJgEgAgJgSQgFAEgBADIgCAHIAkAAIgCgHQgBgEgGgDQgEgDgFAAQgFAAgFADg");
	this.shape_30.setTransform(-95.025,26.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgGAkQgHgGAAgLIAAgfIgLAAIAAgNIALAAIAAgPIAPAAIAAAPIASAAIAAANIgSAAIAAAeQAAAFACADQADACAEAAQAFAAAEgCIAEALIgGADIgIABQgKAAgGgFg");
	this.shape_31.setTransform(-101.4,25.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgQAHIAAgNIAhAAIAAANg");
	this.shape_32.setTransform(-106.525,25.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgRAsQgJgCgGgFIAIgMQAEAEAGACQAHACAHAAQALAAAEgFQAGgGAAgJIAAgEQgEAEgEACQgGADgIAAQgKAAgHgEQgHgDgGgIQgEgGAAgKQAAgJAEgIQAFgHAIgEQAIgEAJAAQAHAAAHADQAFADADAEIAAgJIAPAAIAAA3QAAATgJAIQgJAIgSAAQgJAAgIgCgAgJgdQgFACgCAEQgDADAAAHQAAAHADADQACAEAFACQAFACAFAAQAFAAAFgCQAFgDACgDQACgDABgHQgBgHgCgDQgCgEgFgCQgFgDgFAAQgFAAgFADg");
	this.shape_33.setTransform(-113.55,27.275);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AggAiIAAhCIAPAAIAAAIQADgDAFgCQAIgEAGAAQAJAAAFAEQAHADADAGQAEAGAAAKIAAAmIgQAAIAAgjQAAgIgEgGQgEgEgIAAQgEAAgEACQgEACgDAFQgCAFAAAFIAAAig");
	this.shape_34.setTransform(-121.875,26.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgRAeQgJgFgEgHQgFgIABgKQgBgJAFgIQAEgHAJgFQAIgEAJAAQALAAAHAEQAIAFAFAHQAFAIAAAJQAAAKgFAIQgFAHgIAFQgHAEgLAAQgJAAgIgEgAgJgRQgEACgDAFQgDAEAAAGQAAAGADAFQADAFAEACQAEADAFAAQAHAAADgDQAEgCAEgFQACgGAAgFQAAgFgCgFQgEgFgEgCQgDgDgHAAQgFAAgEADg");
	this.shape_35.setTransform(-130.2,26.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgHAuIAAhbIAPAAIAABbg");
	this.shape_36.setTransform(-136.025,24.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.SUBHEAD, new cjs.Rectangle(-136.8,4,150.9,27.9), null);


(lib.PIC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.UWNursingimpact320x50();
	this.instance.setTransform(-160,-25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PIC, new cjs.Rectangle(-160,-25,320,50), null);


(lib.HEAD1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.HEAD1b2x();
	this.instance.setTransform(-19,-11,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1b, new cjs.Rectangle(-19,-11,252,58), null);


(lib.HEAD1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.HEAD1a2x();
	this.instance.setTransform(-19,-68,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1a, new cjs.Rectangle(-19,-68,311,58), null);


// stage content:
(lib.UWSoNImpactDisplay320x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [168];
	// timeline functions:
	this.frame_168 = function() {
		if(!this.alreadyExecuted){
		this.alreadyExecuted=true;
		this.loopNum=1;
		} else {
		this.loopNum++;
		if(this.loopNum==2){
		this.stop();
		}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(168).call(this.frame_168).wait(11));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,2,0,3).p("A46j0MAx1AAAIAAHpMgx1AAAg");
	this.shape.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(179));

	// HEAD1a
	this.instance = new lib.HEAD1a();
	this.instance.setTransform(49.9,28.65,0.66,0.66,0,0,0,135.4,-19.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:135.6,x:100.15,alpha:1},14,cjs.Ease.quintOut).to({_off:true},95).wait(70));

	// HEAD1b
	this.instance_1 = new lib.HEAD1b();
	this.instance_1.setTransform(49.9,8.85,0.66,0.66,0,0,0,135.4,-19.2);
	this.instance_1.alpha = 0;
	this.instance_1.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,0,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(43).to({_off:false},0).to({regX:135.6,x:100.15,alpha:1},14,cjs.Ease.quintOut).to({_off:true},52).wait(70));

	// SUBHEAD
	this.instance_2 = new lib.SUBHEAD();
	this.instance_2.setTransform(169.45,16,1.1297,1.1297,0,0,0,0.1,9.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(109).to({_off:false},0).to({alpha:1},10).wait(50).to({alpha:0},9).wait(1));

	// LOGO
	this.instance_3 = new lib.LOGO300x2502x();
	this.instance_3.setTransform(221,6,0.5,0.5);

	this.instance_4 = new lib.Tween1("synched",0);
	this.instance_4.setTransform(262.75,24.75);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween2("synched",0);
	this.instance_5.setTransform(262.75,24.75);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},109).to({state:[{t:this.instance_4}]},60).to({state:[{t:this.instance_5}]},9).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(169).to({_off:false},0).to({_off:true,alpha:0},9).wait(1));

	// BKGD
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2C5AA9").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_1.setTransform(160,25);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(109).to({_off:false},0).wait(70));

	// PIC
	this.instance_6 = new lib.PIC();
	this.instance_6.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(179));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(104,21.4,216.5,42.9);
// library properties:
lib.properties = {
	id: '0957C5EC3B874C629166840920B09671',
	width: 320,
	height: 50,
	fps: 24,
	color: "#999999",
	opacity: 1.00,
	manifest: [
		{src:"images/UWSoN_Impact_Display_320x50_atlas_P_1.png", id:"UWSoN_Impact_Display_320x50_atlas_P_1"},
		{src:"images/UWSoN_Impact_Display_320x50_atlas_NP_1.jpg", id:"UWSoN_Impact_Display_320x50_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0957C5EC3B874C629166840920B09671'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;